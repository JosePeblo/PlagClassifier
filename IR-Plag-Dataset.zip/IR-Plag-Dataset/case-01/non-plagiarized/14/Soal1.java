

import java.util.Scanner;

/**
 *
 * @author 4900D0A19B6894A4A514E9FF3AFCC2C0
 */
public class Soal1 {
    public static void main(String[] args) {
        for(int i = 0; i<5; i++)    
            System.out.println("Welcome to Java");
        
    }
}
