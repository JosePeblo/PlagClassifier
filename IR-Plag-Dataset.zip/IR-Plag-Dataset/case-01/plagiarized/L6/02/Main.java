public class Main {

    public static void main(String[] args) {
	//print "welcome to java" 5x
    String java="Welcome To Java";
for(int baris=9;baris>=0;baris-=2){
    System.out.print(java);
    System.out.println();
}
    }
}
