



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 020A6EC1A4D0C5BDB29FF826A462DA1C5D88CF08B60A4744AFFD95C61A0C3C7E
 */
public class Main {
    public static void main(String[] args) { 
        cetak();
    }
    public static void cetak(){
        System.out.println("Welcome to Java"); 
        System.out.println("Welcome to Java"); 
        System.out.println("Welcome to Java"); 
        System.out.println("Welcome to Java"); 
        System.out.println("Welcome to Java");
    }
}
