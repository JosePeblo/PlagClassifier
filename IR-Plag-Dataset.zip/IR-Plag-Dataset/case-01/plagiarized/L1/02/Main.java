public class Main {

    public static void main(String[] args) {
        //print "Welcome To Java"

    System.out.println("Welcome to Java");
    System.out.println("Welcome to Java");
    System.out.println("Welcome to Java");
    System.out.println("Welcome to Java");
    System.out.println("Welcome to Java");

    }
}
